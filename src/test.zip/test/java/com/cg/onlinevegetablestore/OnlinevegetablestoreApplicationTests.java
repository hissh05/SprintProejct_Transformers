package com.cg.onlinevegetablestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinevegetablestoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
